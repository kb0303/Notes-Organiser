import React from 'react'
// import noteContext from '../context/notes/noteContext';

const About = () => {
  
  return (
    <div>
      This is about page
    </div>
  )
}

export default About